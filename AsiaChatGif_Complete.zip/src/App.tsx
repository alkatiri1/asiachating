import React from "react";
import Chat from "./components/Chat";
import Login from "./components/Login";
import GifMaker from "./components/GifMaker";

const App: React.FC = () => {
  return (
    <div className="app">
      <Login />
      <Chat />
      <GifMaker />
    </div>
  );
};

export default App;