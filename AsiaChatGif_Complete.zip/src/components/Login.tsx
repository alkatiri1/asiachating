import React from "react";

const Login: React.FC = () => {
  return (
    <div className="login-screen">
      <h1>Welcome to AsiaChat</h1>
      <button>Sign in with Google</button>
    </div>
  );
};

export default Login;