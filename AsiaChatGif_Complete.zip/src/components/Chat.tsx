import React from "react";

const Chat: React.FC = () => {
  return (
    <div className="chat-box">
      <p>Chat system coming soon...</p>
    </div>
  );
};

export default Chat;