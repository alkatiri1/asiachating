import React from "react";

const GifMaker: React.FC = () => {
  return (
    <div className="gif-maker">
      <h2>Create your GIF</h2>
      <button>Start Drawing</button>
    </div>
  );
};

export default GifMaker;